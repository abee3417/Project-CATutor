#ifndef _LOGIC_GATES_H_
#define _LOGIC_GATES_H_

#include "adder.h"
#include "mux.h"
#include "shifter.h"
#include "extension_unit.h"

#endif