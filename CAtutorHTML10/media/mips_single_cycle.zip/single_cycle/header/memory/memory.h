#ifndef _MEMORY_H_
#define _MEMORY_H_

#include "../bit_functions/bit_functions.h"

char mem[0xffffffff];

#endif