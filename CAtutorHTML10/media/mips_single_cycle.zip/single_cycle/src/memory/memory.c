#include "../../header/memory/memory.h"
#include <stdlib.h>

char mem[0xffffffff] = {0, };
